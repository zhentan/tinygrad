# Local USB PR evidence bundle

This archive contains the qualification records supporting zhentan/tinygrad PR #1.
Packaging the records does not execute a new test run.
SHA256SUMS covers every other entry. Code and harness provenance are in the manifests.

- `pre-rebase/`: the original d72c079 qualification, including all 100 fresh-process attempts.
- `rebase/`: validation after integration onto b45cee5, the separate single-process check,
  CPU fixture failure and fix, transfer output, source mapping, and fork verification.
  hardware-01 passed correctness but exposed repeated compilation and low throughput.
  hardware-02 is the complete acceptance run after staging-cache fix 8eb65a7d.
  The failed lock acquisition in copy-compile-trace.log occurred before GPU access;
  copy-compile-trace-02 is the completed diagnostic run. Red and green cache
  regressions and the focused buffer-retention check are retained separately.
- `ADR.md` and `rebase/PR-DRAFT.md`: architectural explanation and proposed PR body.
- `harness/`: the unchanged canonical benchmark and serial runner.

The old 100/100 result is not a claim about the rebased head. Read the exact commit IDs
and scope in REBASE.md and the PR draft. USB throughput samples are not arithmetic
performance measurements. Multi-GPU, every board variant, and full VRAM capacity are
not qualified by these runs.

Raw manifests retain original workspace paths for provenance. To repeat the harness,
use a matching tinygrad checkout and dependencies with the original sibling
linux-current-evidence layout; select the external USB NV target and matching CUDA
headers. The hardware pytest runner validates device identity and serializes access.
The canonical runner requires a clean checkout and stops at the first failure.
