#!/usr/bin/env python3
"""Run the canonical USB/NV benchmark serially and retain every attempt."""
from __future__ import annotations

import argparse, datetime, fcntl, hashlib, json, os, shlex, subprocess, sys, time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "tinygrad"
BENCHMARK = ROOT / "linux-current-evidence" / "nv_usb_stability_benchmark.py"
RUNS = ROOT / "linux-current-evidence" / "nv-usb-stability-runs"
PYTHON = REPO / ".venv" / "bin" / "python"
COMMAND = ["timeout", "--signal=TERM", "--kill-after=10s", "120s", "env", "DEV=USB+NV:CUDA", "PYTHONPATH=.",
           "PYTHONUNBUFFERED=1", str(PYTHON), str(BENCHMARK)]


def git_value(*args: str) -> str:
  return subprocess.check_output(("git", "-C", str(REPO), *args), text=True).strip()


def candidate() -> dict[str, str]:
  dirty = git_value("status", "--porcelain")
  if dirty: raise RuntimeError(f"candidate tinygrad worktree is dirty:\n{dirty}")
  return {"head": git_value("rev-parse", "HEAD"), "tree": git_value("rev-parse", "HEAD^{tree}"),
          "branch": git_value("branch", "--show-current")}


def sha256_file(path: Path) -> str:
  digest = hashlib.sha256()
  with path.open("rb") as stream:
    for block in iter(lambda: stream.read(1024 * 1024), b""): digest.update(block)
  return digest.hexdigest()


def inputs() -> dict[str, Any]:
  return {"candidate": candidate(),
          "benchmark": {"path": str(BENCHMARK), "sha256": sha256_file(BENCHMARK)},
          "runner": {"path": str(Path(__file__).resolve()), "sha256": sha256_file(Path(__file__).resolve())},
          "command": COMMAND}


def validate_pass_stdout(stdout: bytes) -> dict[str, Any]:
  lines = [line for line in stdout.decode("utf-8").splitlines() if line.strip()]
  if len(lines) != 1: raise RuntimeError(f"successful benchmark emitted {len(lines)} non-empty stdout lines, expected 1")
  try: payload = json.loads(lines[0])
  except json.JSONDecodeError as error: raise RuntimeError("successful benchmark stdout is not JSON") from error
  if payload.get("status") != "PASS" or payload.get("benchmark") != "nv_usb_stability_v1":
    raise RuntimeError(f"successful benchmark emitted an invalid verdict: {payload!r}")
  return payload


def write_json(path: Path, value: Any) -> None:
  temporary = path.with_suffix(path.suffix + ".tmp")
  temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
  temporary.replace(path)


def parse_args() -> argparse.Namespace:
  parser = argparse.ArgumentParser()
  parser.add_argument("--count", type=int, choices=(1, 100), required=True)
  return parser.parse_args()


def main() -> int:
  args = parse_args()
  if not BENCHMARK.is_file() or not PYTHON.is_file(): raise RuntimeError("benchmark or production interpreter is missing")
  initial = inputs()
  RUNS.mkdir(mode=0o700, parents=True, exist_ok=True)
  lock_path = RUNS / ".runner.lock"
  lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC, 0o600)
  run_dir: Path | None = None
  manifest: dict[str, Any] | None = None
  try:
    try: fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error: raise RuntimeError(f"another benchmark runner holds {lock_path}") from error

    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    run_dir = RUNS / f"{stamp}-{initial['candidate']['head'][:12]}-{args.count:03d}"
    run_dir.mkdir(mode=0o700)
    manifest = {"schema": 2, "status": "running", "requested": args.count, "passes": 0,
                "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "inputs": initial,
                "command_display": shlex.join(COMMAND), "attempts": []}
    write_json(run_dir / "manifest.json", manifest)

    for number in range(1, args.count + 1):
      current = inputs()
      if current != initial: raise RuntimeError(f"candidate or harness changed during series: {initial!r} -> {current!r}")
      started_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
      started = time.monotonic_ns()
      completed = subprocess.run(COMMAND, cwd=REPO, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
      duration_ms = round((time.monotonic_ns() - started) / 1_000_000, 3)
      completed_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
      prefix = run_dir / f"attempt-{number:03d}"
      prefix.with_suffix(".stdout").write_bytes(completed.stdout)
      prefix.with_suffix(".stderr").write_bytes(completed.stderr)
      attempt = {"number": number, "returncode": completed.returncode, "duration_ms": duration_ms,
                 "started_utc": started_utc, "completed_utc": completed_utc,
                 "stdout_sha256": hashlib.sha256(completed.stdout).hexdigest(),
                 "stderr_sha256": hashlib.sha256(completed.stderr).hexdigest()}
      if completed.returncode == 0:
        try: attempt["verdict"] = validate_pass_stdout(completed.stdout)
        except RuntimeError as error: attempt["validation_error"] = str(error)
      write_json(prefix.with_suffix(".json"), attempt)
      manifest["attempts"].append(attempt)
      if inputs() != initial: raise RuntimeError("candidate or harness changed while an attempt was running")
      if completed.returncode != 0 or "validation_error" in attempt:
        manifest.update(status="failed", failed_attempt=number, completed_utc=completed_utc)
        write_json(run_dir / "manifest.json", manifest)
        print(json.dumps({"status": "FAIL", "run_dir": str(run_dir), **attempt}, sort_keys=True), flush=True)
        return 1
      manifest["passes"] = number
      write_json(run_dir / "manifest.json", manifest)
      print(json.dumps({"status": "PASS", "attempt": number, "requested": args.count, "duration_ms": duration_ms}, sort_keys=True), flush=True)

    manifest.update(status="passed", completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_json(run_dir / "manifest.json", manifest)
    print(json.dumps({"status": "PASS", "passes": args.count, "run_dir": str(run_dir),
                      "candidate": initial["candidate"]}, sort_keys=True), flush=True)
    return 0
  except Exception as error:
    if run_dir is not None and manifest is not None:
      manifest.update(status="harness_error", completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      harness_error={"type": type(error).__name__, "error": str(error)})
      write_json(run_dir / "manifest.json", manifest)
    raise
  finally:
    os.close(lock_fd)


if __name__ == "__main__":
  try: result = main()
  except Exception as error:
    print(json.dumps({"status": "HARNESS_ERROR", "error_type": type(error).__name__, "error": str(error)}, sort_keys=True),
          file=sys.stderr, flush=True)
    raise
  sys.exit(result)
