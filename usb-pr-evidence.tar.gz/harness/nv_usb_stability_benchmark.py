#!/usr/bin/env python3
"""One deterministic normal-runtime calculation on the external Chestnut RTX 3090."""
from __future__ import annotations

import gc, hashlib, json, math, os, struct, subprocess, sys, time, traceback
from pathlib import Path
from typing import Any

EXPECTED_TARGET = "USB+NV:CUDA"
EXPECTED_DEVICE = "NV"
CHESTNUT_IDS = ("3801", "0001")
RTX_3090_FE_ID = 0x220410DE
RTX_3090_FE_SUBSYSTEM = 0x147D10DE
MATRIX_SIZE = 32
ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "tinygrad"
FAILURE_CONTEXT: dict[str, Any] = {"phase": "startup"}


def require(condition: bool, message: str) -> None:
  if not condition: raise RuntimeError(message)


def read_text(path: Path) -> str:
  return path.read_text(encoding="ascii").strip()


def chestnut_inventory(sysfs: Path = Path("/sys/bus/usb/devices")) -> dict[str, str]:
  matches: list[dict[str, str]] = []
  for entry in sysfs.iterdir():
    try: ids = read_text(entry / "idVendor").lower(), read_text(entry / "idProduct").lower()
    except (FileNotFoundError, NotADirectoryError): continue
    if ids != CHESTNUT_IDS: continue
    item = {"physical_port": entry.name, "busnum": read_text(entry / "busnum"), "devnum": read_text(entry / "devnum"),
            "speed": read_text(entry / "speed"), "authorized": read_text(entry / "authorized"),
            "configuration": read_text(entry / "bConfigurationValue"), "product": read_text(entry / "product")}
    item["runtime_bus"] = f"usb:{int(item['busnum'])}-{int(item['devnum'])}"
    matches.append(item)
  require(len(matches) == 1, f"expected exactly one Chestnut USB device, found {len(matches)}")
  found = matches[0]
  require(found["speed"] == "10000", f"Chestnut link is {found['speed']} Mb/s, expected 10000 Mb/s")
  require(found["authorized"] == "1", "Chestnut USB device is not authorized")
  require(found["configuration"] == "1", f"Chestnut configuration is {found['configuration']!r}, expected '1'")
  require(found["product"].startswith(("custom", "AS2462")), f"unexpected Chestnut product {found['product']!r}")
  return found


def matrix_inputs(n: int = MATRIX_SIZE) -> tuple[list[float], list[float]]:
  left = [float(((row * 7 + col * 3) % 17) - 8) for row in range(n) for col in range(n)]
  right = [float(((row * 5 - col * 2) % 13) - 6) for row in range(n) for col in range(n)]
  return left, right


def expected_matmul(left: list[float], right: list[float], n: int = MATRIX_SIZE) -> list[float]:
  return [float(sum(int(left[row*n+k]) * int(right[k*n+col]) for k in range(n))) for row in range(n) for col in range(n)]


def git_value(*args: str) -> str:
  return subprocess.check_output(("git", "-C", str(REPO), *args), text=True).strip()


def provenance() -> dict[str, Any]:
  require(Path.cwd().resolve() == REPO.resolve(), f"benchmark must run from {REPO}")
  require(not git_value("status", "--porcelain"), "candidate tinygrad worktree is dirty")
  return {"head": git_value("rev-parse", "HEAD"), "tree": git_value("rev-parse", "HEAD^{tree}"),
          "target": os.environ.get("DEV"), "python": sys.executable}


def runtime_identity(dev: Any, inventory: dict[str, str]) -> dict[str, Any]:
  require(type(dev.iface).__name__ == "USBIface", f"selected interface is {type(dev.iface).__name__}, expected USBIface")
  pci_dev = dev.iface.pci_dev
  require(type(pci_dev).__name__ == "USBPCIDevice", f"selected PCI transport is {type(pci_dev).__name__}, expected USBPCIDevice")
  require(pci_dev.pcibus == inventory["runtime_bus"],
          f"runtime opened {pci_dev.pcibus}, inventory selected {inventory['runtime_bus']}")
  device_id, subsystem_id = pci_dev.read_config(0, 4), pci_dev.read_config(0x2C, 4)
  require(device_id == RTX_3090_FE_ID, f"unexpected GPU PCI ID {device_id:#010x}")
  require(subsystem_id == RTX_3090_FE_SUBSYSTEM, f"unexpected GPU subsystem ID {subsystem_id:#010x}")
  product = pci_dev.usb.usb.product
  require(product.startswith(("custom", "AS2462")), f"unexpected runtime Chestnut product {product!r}")
  return {**inventory, "runtime_product": product, "gpu_pci_id": f"{device_id:#010x}",
          "gpu_subsystem_id": f"{subsystem_id:#010x}", "interface": type(dev.iface).__name__}


def run_workload(dev: Any, Tensor: Any, dtypes: Any) -> tuple[list[float], list[float], float, float]:
  left_data, right_data = matrix_inputs()
  expected = expected_matmul(left_data, right_data)
  FAILURE_CONTEXT["phase"] = "upload_inputs"
  left = Tensor(left_data, device=EXPECTED_DEVICE, dtype=dtypes.float).reshape(MATRIX_SIZE, MATRIX_SIZE).realize()
  right = Tensor(right_data, device=EXPECTED_DEVICE, dtype=dtypes.float).reshape(MATRIX_SIZE, MATRIX_SIZE).realize()
  FAILURE_CONTEXT["phase"] = "execute_gpu"
  result = (left @ right).realize()
  dev.synchronize()
  computed_at = time.perf_counter()
  FAILURE_CONTEXT["phase"] = "readback"
  actual = [float(value) for row in result.tolist() for value in row]
  read_at = time.perf_counter()
  FAILURE_CONTEXT["phase"] = "verify"
  require(len(actual) == len(expected), f"result length {len(actual)} != {len(expected)}")
  mismatches = [(index, got, want) for index, (got, want) in enumerate(zip(actual, expected)) if got != want]
  require(not mismatches, f"result mismatch count={len(mismatches)} first={mismatches[:4]}")
  require(all(math.isfinite(value) for value in actual), "result contains a non-finite value")
  return actual, expected, computed_at, read_at


def cleanup_device(dev: Any, Device: Any) -> list[str]:
  errors: list[str] = []
  for label, action in (("synchronize", dev.synchronize), ("free_cache", dev.allocator.free_cache), ("finalize", dev.finalize)):
    try: action()
    except BaseException as error: errors.append(f"{label}: {type(error).__name__}: {error}")
  Device._opened_devices.discard(EXPECTED_DEVICE)
  return errors


def execute() -> dict[str, Any]:
  started = time.perf_counter()
  FAILURE_CONTEXT.clear()
  FAILURE_CONTEXT["phase"] = "environment"
  require(os.environ.get("DEV") == EXPECTED_TARGET, f"require DEV={EXPECTED_TARGET}")
  source = provenance()
  FAILURE_CONTEXT["source"] = source
  FAILURE_CONTEXT["phase"] = "inventory"
  identity = chestnut_inventory()
  FAILURE_CONTEXT["identity"] = identity

  FAILURE_CONTEXT["phase"] = "runtime_import"
  from tinygrad import Device, Tensor, dtypes
  from tinygrad.helpers import DEV
  require((DEV.interface, DEV.device, DEV.renderer) == ("USB", "NV", "CUDA"),
          f"parsed target is interface={DEV.interface!r}, device={DEV.device!r}, renderer={DEV.renderer!r}")
  require(Device.DEFAULT == EXPECTED_DEVICE, f"default device is {Device.DEFAULT!r}, expected {EXPECTED_DEVICE!r}")

  phase_started = time.perf_counter()
  opened_at = computed_at = read_at = phase_started
  dev: Any | None = None
  primary_error: str | None = None
  failed_phase: str | None = None
  actual: list[float] = []
  try:
    FAILURE_CONTEXT["phase"] = "device_open"
    dev = Device[Device.DEFAULT]
    opened_at = time.perf_counter()
    FAILURE_CONTEXT["phase"] = "runtime_identity"
    identity = runtime_identity(dev, identity)
    FAILURE_CONTEXT["identity"] = identity
    actual, _, computed_at, read_at = run_workload(dev, Tensor, dtypes)
  except BaseException as error:
    failed_phase = str(FAILURE_CONTEXT["phase"])
    primary_error = f"{type(error).__name__}: {error}"
    FAILURE_CONTEXT["origin_traceback"] = "".join(traceback.format_exception(error))
    error.__traceback__ = None

  gc.collect()
  FAILURE_CONTEXT["phase"] = "shutdown"
  cleanup_errors = [] if dev is None else cleanup_device(dev, Device)
  finished = time.perf_counter()
  if primary_error is not None or cleanup_errors:
    FAILURE_CONTEXT["phase"] = failed_phase or "shutdown"
    if cleanup_errors: FAILURE_CONTEXT["cleanup_errors"] = cleanup_errors
    details = [] if primary_error is None else [f"{failed_phase}: {primary_error}"]
    raise RuntimeError("; ".join(details + cleanup_errors))

  FAILURE_CONTEXT["phase"] = "complete"
  packed = struct.pack(f"<{len(actual)}f", *actual)
  return {"status": "PASS", "benchmark": "nv_usb_stability_v1", **source, "identity": identity,
          "matrix": {"dtype": "float32", "m": MATRIX_SIZE, "n": MATRIX_SIZE, "k": MATRIX_SIZE,
                     "elements_verified": len(actual), "result_sha256": hashlib.sha256(packed).hexdigest()},
          "timings_ms": {"device_open": round((opened_at-phase_started)*1000, 3),
                         "compute_and_sync": round((computed_at-opened_at)*1000, 3),
                         "read_and_verify": round((read_at-computed_at)*1000, 3),
                         "shutdown": round((finished-read_at)*1000, 3),
                         "total": round((finished-started)*1000, 3)}}


if __name__ == "__main__":
  try: print(json.dumps(execute(), sort_keys=True), flush=True)
  except BaseException as error:
    FAILURE_CONTEXT.setdefault("origin_traceback", "".join(traceback.format_exception(error)))
    print(json.dumps({"status": "FAIL", "benchmark": "nv_usb_stability_v1", "error_type": type(error).__name__,
                      "error": str(error), **FAILURE_CONTEXT}, sort_keys=True), file=sys.stderr, flush=True)
    raise
