---
status: accepted
---

# Run native GA102 compute through Chestnut using the existing NV backend

An external RTX 3090 connected through Chestnut needs GPU initialization, queue submission, and memory transfers that work over USB. We keep tinygrad's tensor compiler and NV backend, initialize the qualified GA102 directly with NVIDIA's signed firmware, and lower the host-side HCQ operations into USB transactions. Controller SRAM provides an upload staging window; an explicit GPU copy and completion signal provide ordered readback.

This records the implementation on `codex/chestnut-usb-stability`, including its rebase onto upstream `b45cee5ccd127266a70a8fed14ebe43196f7d95d`. The code/test snapshot described below is `8eb65a7d20a9de40a5ad2ebee42fd8ab2fddc25a`. The qualified configuration is one external RTX 3090 FE, GA102, through the existing Chestnut firmware at a negotiated 10,000 Mb/s USB link.

## Architectural boundary

`DEV=USB+NV:CUDA` selects the USB interface, NV device backend, and CUDA-C renderer. NVRTC compiles the GPU programs; execution uses tinygrad's queues through Chestnut. Tensor programs, arithmetic lowering, autograd, and TinyJit retain their existing interfaces.

Here, **native initialization** means the host performs the supported GA102 resource and engine setup instead of delegating that setup to GSP resource-management RPCs. It still uses authenticated NVIDIA firmware. **HCQ** is tinygrad's hardware-command-queue representation and its compiled host-side submission path. **Controller SRAM**, host RAM, and GPU VRAM are separate address spaces; a USB-backed MMIO view is not a host pointer that generated CPU code can dereference.

```mermaid
flowchart TD
  T[Tensor program and TinyJit] --> N[Existing compiler and NV backend]
  N --> G[GPU arithmetic programs]
  N --> H[HCQ calls and dependencies]
  H --> S[Native USB staging and host-I/O lowering]
  S --> U[Checked libusb transactions]
  U --> C[Chestnut controller and PCIe bridge chain]
  C --> V[RTX 3090 VRAM and compute/copy queues]
  G --> V
  I[Native GA102 initialization] --> V
```

## Initialization and resource ownership

1. **Discover and configure the transport.** `USBPCIDevice` numbers the actual point-to-point PCIe bridge chain and finds the endpoint instead of assuming a fixed downstream bus. It programs supported resizable BAR entries with endpoint memory decoding disabled during reconfiguration. Controller allocations describe every backing page.
2. **Prepare the GPU's address space.** The native device reuses the NV memory manager. Page mappings can express the memory kind and privileged access required by engine context buffers. TU102-family MMU invalidation selects the actual root and waits for completion; video-memory directory entries use the appropriate attributes.
3. **Load the signed initialization package.** `nogsp.py` builds the GA102 ACR package from firmware selected by content hashes. It validates descriptor sizes, ranges, alignment, and expected layouts before constructing the images. The runtime stages the package, compares its full readback, and verifies the protected-memory range. When VRAM initialization is required, it runs the packaged signed memory scrubber before ACR and verifies completion. Falcon loading supports the memory source and register layout needed by these firmware components.
4. **Bring up the compute engine.** SEC2 starts the FECS and GPCCS context-control firmware. `gr.py` initializes the qualified topology, firmware register tables, cache/ZBC state, context control, and context buffers. It asks the engine to generate a golden context, then uses that template and per-context patches to bind compute channels. Channel groups share the appropriate GR context; copy channels receive their own copy context.
5. **Expose the resources through the existing backend.** `USBIface` implements the limited resource-manager operations used by `NVDevice`: logical object handles, memory registration, compute/copy channels, submission tokens, and channel-group scheduling. Unsupported operations and unexpected layouts raise errors. Ordinary allocations stay in VRAM; the dedicated controller SRAM allocation is explicit. Freeing an allocation also removes its native memory registration, permitting valid address reuse.
6. **Finish cleanly.** Constructor failures finalize the interface and preserve both primary and cleanup errors. The native device finalizes through the existing external endpoint reset path, which checks identity and BAR restoration. Bus mastering is disabled during reset and controlled initialization stages. USB initialization failures close opened libusb handles.

The implementation asserts several firmware and topology assumptions. The acceptance evidence establishes this RTX 3090 FE configuration; it does not establish support for every GA102 board or other NVIDIA generation.

## One upload, execution, and readback

For an upload, the copy-preparation hook recognizes a transfer to the native USB device before generic copy batching. A non-CPU host source first moves into CPU staging. The host waits for the current device timeline before reusing the upload area, writes a bounded chunk to the reserved controller SRAM window, and lets the GPU copy engine move that chunk into the destination VRAM allocation. The upload window is 256 KiB; larger transfers repeat the same ordered operation, including their final short chunk.

For execution, the existing NV backend supplies the compute program and queue commands. HCQ retains their dependencies and compiles the host submission work. USB lowering turns remote loads, writes, and queue updates into controller transactions. CPU-side queue counters remain host-resident; GPU-visible ring and doorbell accesses remain transport-mediated.

For readback, the native path uses a separate 256 KiB VRAM window. Before each staging copy it waits on the current device timeline, copies the producing buffer into that window, and signals completion. Only after observing completion does the host read the window through the controller's PCIe streaming operation, then copy the received bytes into the requested host destination. The completion signal proves that the readback copy completed; the preceding timeline wait is what establishes that the compute producer finished before the copy began.

The upload and readback windows have different ownership and synchronization requirements. The existing AMD USB batching layout remains in its existing module; the native NV layout is implemented in `runtime/support/nv/usb.py`.

## Correctness rules preserved by the compiler and transport

| Rule | Implementation and reason |
| --- | --- |
| A remote address is not a host pointer | USB lowering mediates remote memory operations; nested views and `AFTER` dependencies survive address calculation. |
| Runtime-dependent addresses stay at runtime | HCQ distinguishes link-time constants from values requiring runtime loads or dependencies. Dependent addresses are materialized without moving their required work ahead of execution. |
| Link-time writes obey the same byte semantics | Scalar and vector patches use the underlying byte offset and element width. Sub-dword USB writes enable only the intended byte lanes; scatter writes retain order. |
| Timeline values name the actual submission | Native USB uses the current HCQ timeline representation and upstream's preincrement snapshot convention. Upload waits do not poll obsolete placeholder storage. |
| Readback follows its producer | The direct readback submit explicitly waits for prior compute because it bypasses generic batch scheduling. |
| A short transfer is a failure | Both libusb status and transferred length are checked. A generated host submission stops before dependent work after an error and reports it to the executor. |
| Failed writes do not populate caches | Binary-upload caching records success only after the underlying write succeeds. |
| Transfers have bounded, valid ranges | Synchronous bulk writes use bounded chunks; controller XDATA accesses and streaming address-width boundaries are checked. Streams cannot silently cross the 32-bit encoding boundary. |
| MMIO synchronization is not recursive | Shared USB MMIO access retains its synchronization boundary without re-entering synchronization while it is already being performed. |
| Allocation reuse is valid | Released native memory registrations are removed, while collisions between live allocations remain errors. |

These are necessary properties of ordinary execution. Retry loops in a benchmark would conceal violations, so qualification retains the first failure and stops the sequence.

## Why the branch has this shape

The implementation extends the existing backend at the interface, copy-preparation, lowering, and bufferization seams. It uses the existing `UOp`, `PatternMatcher`, `Buffer`, and queue abstractions rather than introducing another tensor API or scheduler. Keeping firmware-package construction separate from register operations makes the binary layouts testable without hardware. The native resource adapter implements the operations this backend needs instead of a general resource manager.

Using host memory as though it were GPU-visible would violate the USB topology. Staging is therefore an explicit part of the transfer graph. Reusing the AMD transfer layout would also conflict with SRAM reserved by native GA102 initialization; the distinct NV transfer module makes that constraint visible. Implementing a separate execution backend would duplicate the arithmetic and JIT machinery that the existing NV backend already provides.

The code/test diff at the snapshot above is 4,043 additions and 113 removals across 22 files: 1,996 added test lines and 2,047 added runtime lines. Of the runtime additions, 1,489 are in `gr.py`, `nogsp.py`, and `nvdev.py`, which perform the previously missing GA102 setup. The shared HCQ module adds 50 lines and removes 10; the executor adds four lines. These counts describe scope, not a proof that the implementation is minimal. The design favors short functions and existing abstractions while retaining explicit checks where incorrect hardware state would otherwise be difficult to diagnose.

For comparison, upstream at the stated base has 75,674 Python lines under `test/` and 33,945 under `tinygrad/` excluding generated bindings. Tests are 69.0% of that combined scope; this branch is 68.4% (77,646 test lines and 35,900 library lines). Counting all other Python code as well, but still excluding `tinygrad/runtime/autogen/`, tests are about 45% in each version. These are physical line counts including blanks and comments, not coverage percentages. There are 90 net additional test-prefixed function definitions over upstream's 5,617; parametrization and subtests make collected case counts different.

Test volume alone does not establish value. Full-data transfer checks and regressions for observed failures protect behavior, while independent firmware-layout and register-encoding expectations protect hardware contracts that are hard to exercise in ordinary CI. The large native-initialization test module repeats small VRAM/register mocks; consolidating that setup is a reasonable future cleanup. Assertions that merely duplicate an implementation detail should be assessed individually, rather than using a test-line target to decide what to remove.

The rebase also moved upstream's HCQ cache lookup after copy preparation. Generating fresh scratch parameters on every USB copy then caused repeated compilation: warm upload fell to 3.43 MB/s. Native USB now reuses staging graphs only when the inputs contain no concrete buffers, and includes the staging window in the cache key. Concrete-buffer copies remain uncached so application allocations are not retained. The existing compiler regression checks reuse across new inputs of the same shape; the upstream hardware buffer-retention test also passes. An isolated measurement after the fix reached 97.75 MB/s upload and 1.57 MB/s download. Full post-fix qualification is recorded below.

## Map of the branch

Paths in this table are relative to the repository root. Together they account for every changed code/test file at the snapshot above.

| Files | Responsibility and regression coverage |
| --- | --- |
| [tinygrad/runtime/support/system.py](../../tinygrad/runtime/support/system.py); [test/unit/test_system_pci_scan_bus.py](../../test/unit/test_system_pci_scan_bus.py) | Bridge discovery, BAR programming, SRAM page descriptions, endpoint reset and restoration. |
| [tinygrad/runtime/support/usb.py](../../tinygrad/runtime/support/usb.py); [test/unit/test_usb.py](../../test/unit/test_usb.py); [test/mockgpu/usb.py](../../test/mockgpu/usb.py) | Transfer lengths, chunking, address bounds, MMIO synchronization, initialization cleanup, and mock behavior. |
| [tinygrad/runtime/support/memory.py](../../tinygrad/runtime/support/memory.py); NV page tables in `nvdev.py`; [test/unit/test_nv_vmm.py](../../test/unit/test_nv_vmm.py) | Mapping kind/privilege attributes, directory encoding, root-specific MMU invalidation and completion. |
| [tinygrad/runtime/support/nv/nogsp.py](../../tinygrad/runtime/support/nv/nogsp.py), `ip.py`, `gr.py`, `nvdev.py`; [test/null/test_nv_nogsp.py](../../test/null/test_nv_nogsp.py) | Firmware package construction, signed bootstrap and VRAM initialization, GR setup, golden contexts, native channels and scheduling. |
| [tinygrad/runtime/ops_nv.py](../../tinygrad/runtime/ops_nv.py); [test/null/test_nv_usb_iface.py](../../test/null/test_nv_usb_iface.py) | USB interface selection, native resource adapter, allocation ownership and reuse, runtime windows, cleanup. |
| [tinygrad/runtime/support/nv/usb.py](../../tinygrad/runtime/support/nv/usb.py); [test/null/test_hcq_iface.py](../../test/null/test_hcq_iface.py) | Staging, remote loads/stores, byte lanes, readback completion, and compiler dispatch. |
| [tinygrad/runtime/support/hcq2.py](../../tinygrad/runtime/support/hcq2.py); [tinygrad/engine/realize.py](../../tinygrad/engine/realize.py); [test/device/test_hcq2.py](../../test/device/test_hcq2.py) | Checked host calls, timeline convention, runtime address dependencies, link-time patches and write-cache correctness. |
| [tinygrad/runtime/autogen/nvrtc.py](../../tinygrad/runtime/autogen/nvrtc.py); [test/unit/test_nvrtc.py](../../test/unit/test_nvrtc.py) | Discover NVRTC installed by the NVIDIA Python wheel as well as existing toolkit paths. |
| [test/external/external_test_usb_asm24.py](../../test/external/external_test_usb_asm24.py) | Select the active USB backend and its actual window sizes; verify boundaries, batched transfers, changing JIT inputs, sentinel payloads and a 64 MiB round trip. |

After the rebase, upstream's earlier buffer mapping required buffer-backed mocks in the staging regression. That focused fixture change preserves the original assertions and compiled-matcher warmup; it does not add a runtime workaround.

## Evidence and its limits

The pre-rebase candidate `d72c079de9af8d0639933b7b549661a0f798d2b9` passed 100 consecutive fresh-process runs of the canonical 32×32 FP32 matrix multiplication. Each run initialized normally, uploaded both inputs, verified all 1,024 outputs, and shut down cleanly. The runner stopped on failure and required unchanged code, benchmark and settings. An independent artifact audit checked all attempts, exits, hashes and hardware identities. This is repeated application startup, not 100 physical power cycles.

That candidate also passed the selected upstream smoke/operator/JIT tests and all nine USB integrity/timing tests. The broader tests exposed allocation-registration reuse, obsolete upload timeline storage, missing signed VRAM initialization, and premature readback; each received a focused fix and regression coverage. Thus the small repeated benchmark and the broader operator/transfer suite supply complementary evidence.

At the rebased runtime/test commit `8eb65a7d20a9de40a5ad2ebee42fd8ab2fddc25a`, the complete selected hardware gate passed **520 tests, with 21 skips and 165 passing subtests**. This includes all nine USB integrity/timing tests and the existing HCQ buffer-retention test. Pytest, process exit and normal device cleanup succeeded. The CPU/reference gate passed **636 tests, with 44 skips and 239 passing subtests**; mypy passed for 218 source files and Ruff passed. The selected five upstream smoke/operator/JIT files and their test helper are byte-identical to `b45cee5`.

The full post-fix sequence measured 98.20 MB/s upload and 1.56 MB/s download as warm medians; its first transfer samples were 719.21 ms and 1,796.11 ms respectively. The isolated post-fix samples above and this full sequence are distinct runs, and all samples are retained.

Pre-rebase transfer measurements used ten 2.00 MB transfers per direction. The first samples were 749.30 ms upload and 1,833.29 ms download. The median of the remaining nine samples was 107.65 MB/s upload and 1.57 MB/s download. All samples were retained; the first transfer was excluded only from the explicitly labeled warm statistic. These are host/device transfer measurements on this setup, not GPU arithmetic throughput or a comparison with a directly attached 3090. The low download rate remains a limitation. The rebase measurements and cache correction above are reported separately from this pre-rebase baseline.

The 64 MiB integrity check verifies every returned byte but does not qualify the entire 24 GiB VRAM capacity. Single-device tests do not establish multi-GPU support. Existing test skips and numerical tolerances remain unchanged. A new code revision requires new evidence; the old 100/100 count is not carried over by a rebase.

The raw qualification records are kept in the handoff workspace's `linux-current-evidence/backend-usb-qualification-20260909`, `linux-current-evidence/nv-usb-stability-runs`, and `linux-current-evidence/fork-rebase-20260909-b45cee5`. The [PR evidence branch](https://github.com/zhentan/tinygrad/tree/evidence/chestnut-usb-b45cee5-20260909) provides the curated archive, checksums and reproduction notes independently of this workspace. It keeps generated evidence out of the code diff. The archive distinguishes pre-rebase acceptance from validation of the rebased code.
