"""Independently verify the retained canonical run without opening any GPU."""
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

manifest_path = Path(sys.argv[1]).resolve()
manifest = json.loads(manifest_path.read_text())
evidence = Path(__file__).resolve().parent
repo = evidence.parents[1] / "tinygrad"
expected_head = "d72c079de9af8d0639933b7b549661a0f798d2b9"
expected_tree = "2d3be901b3f439d8b1b9be997dea91b2a35bf982"
expected_digest = "df5a6884c5830e93b08246f83d57ae10648fb903a18f575e0b568e885a32856f"


def require(condition, message):
  if not condition:
    raise RuntimeError(message)


def git(*args):
  return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def digest(path):
  return hashlib.sha256(path.read_bytes()).hexdigest()


require(manifest["status"] == "passed", "series is not complete and passed")
require(manifest["requested"] == manifest["passes"] == len(manifest["attempts"]) == 100, "expected exactly 100 passes")
require(manifest["inputs"]["candidate"] == {
  "head": expected_head, "tree": expected_tree, "branch": "codex/chestnut-usb-stability",
}, "unexpected candidate")
require(git("rev-parse", "HEAD") == expected_head, "current HEAD changed")
require(git("rev-parse", "HEAD^{tree}") == expected_tree, "current tree changed")
require(git("branch", "--show-current") == "codex/chestnut-usb-stability", "current branch changed")
require(not git("status", "--porcelain"), "current worktree is dirty")
for name, expected_hash in {
  "benchmark": "5cff120d9baf485e8a0e152ce4e6a2a8ced9d043ee14af5960a408c0e5029711",
  "runner": "189e937b7c345bf6acb341b0a50c4e914663d5b5147422ed7232821c1f2f842f",
}.items():
  item = manifest["inputs"][name]
  require(item["sha256"] == digest(Path(item["path"])) == expected_hash, f"{name} changed")

identity = manifest["attempts"][0]["verdict"]["identity"]
require(identity["physical_port"] == "4-1" and identity["runtime_bus"] == "usb:4-3", "unexpected USB target")
require(identity["gpu_pci_id"] == "0x220410de" and identity["gpu_subsystem_id"] == "0x147d10de", "unexpected GPU")
require(identity["interface"] == "USBIface" and identity["speed"] == "10000", "unexpected transport")
require(identity["authorized"] == identity["configuration"] == "1", "unexpected USB configuration")
previous_end = datetime.datetime.fromisoformat(manifest["started_utc"])
for number, attempt in enumerate(manifest["attempts"], 1):
  prefix = manifest_path.parent / f"attempt-{number:03d}"
  require(attempt["number"] == number, f"nonconsecutive attempt {number}")
  require(json.loads(prefix.with_suffix(".json").read_text()) == attempt, f"attempt metadata differs: {number}")
  stdout = prefix.with_suffix(".stdout")
  stderr = prefix.with_suffix(".stderr")
  require(digest(stdout) == attempt["stdout_sha256"], f"stdout hash differs: {number}")
  require(digest(stderr) == attempt["stderr_sha256"] and not stderr.read_bytes(), f"stderr present or differs: {number}")
  lines = [line for line in stdout.read_text().splitlines() if line.strip()]
  require(len(lines) == 1 and json.loads(lines[0]) == attempt["verdict"], f"stdout verdict differs: {number}")
  verdict = attempt["verdict"]
  require(attempt["returncode"] == 0 and verdict["status"] == "PASS", f"failed attempt: {number}")
  require(verdict["benchmark"] == "nv_usb_stability_v1" and verdict["target"] == "USB+NV:CUDA", f"unexpected benchmark: {number}")
  require(verdict["head"] == expected_head and verdict["tree"] == expected_tree, f"source differs: {number}")
  require(verdict["identity"] == identity, f"hardware identity differs: {number}")
  require(verdict["matrix"] == {
    "dtype": "float32", "m": 32, "n": 32, "k": 32,
    "elements_verified": 1024, "result_sha256": expected_digest,
  }, f"full readback differs: {number}")
  start = datetime.datetime.fromisoformat(attempt["started_utc"])
  end = datetime.datetime.fromisoformat(attempt["completed_utc"])
  require(previous_end <= start < end, f"attempts overlap or timestamps are invalid: {number}")
  require(0 < attempt["duration_ms"] < 120_000, f"attempt exceeded timeout: {number}")
  previous_end = end
require(previous_end <= datetime.datetime.fromisoformat(manifest["completed_utc"]), "invalid completion time")
for suffix in ("json", "stdout", "stderr"):
  require(len(list(manifest_path.parent.glob(f"attempt-*.{suffix}"))) == 100, f"unexpected extra {suffix} artifacts")

durations = [attempt["duration_ms"] for attempt in manifest["attempts"]]
audit = {
  "status": "PASS", "passes": 100, "attempts": 100,
  "manifest": str(manifest_path), "manifest_sha256": digest(manifest_path),
  "audit_script_sha256": digest(Path(__file__).resolve()),
  "candidate": manifest["inputs"]["candidate"], "identity": identity,
  "all_stdout_and_stderr_hashes_match": True, "all_stderr_empty": True,
  "all_exit_codes_zero": True, "all_1024_elements_verified": True,
  "all_result_digests": expected_digest, "all_attempts_serial_and_consecutive": True,
  "benchmark_and_runner_unchanged": True, "current_worktree_clean": True,
  "started_utc": manifest["started_utc"], "completed_utc": manifest["completed_utc"],
  "duration_ms": {"min": min(durations), "median": statistics.median(durations), "max": max(durations)},
}
print(json.dumps(audit, indent=2, sort_keys=True))
