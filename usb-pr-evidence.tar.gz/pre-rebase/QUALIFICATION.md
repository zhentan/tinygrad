# Backend/JIT and USB integrity qualification

Current status: **all requested qualification gates PASS, including a fresh 100/100 process series**. Final candidate: `d72c079de9af8d0639933b7b549661a0f798d2b9`. The final series and its independent artifact audit both passed on this clean candidate. All seven new commits were pushed without rewriting history to [zhentan/tinygrad, codex/chestnut-usb-stability](https://github.com/zhentan/tinygrad/tree/codex/chestnut-usb-stability); the remote HEAD was verified as d72c079 and the local worktree is clean. See `fork-push.json`.

| Gate | Passed | Skipped | Passing subtests |
| --- | ---: | ---: | ---: |
| Upstream CPU comparison | 512 | 19 | 126 |
| Final combined CPU tests | 612 | 45 | 237 |
| External NV smoke/operator/JIT selection | 510 | 21 | 126 |
| Adapted USB integrity/timing suite | 9 | 0 | 39 |
| Combined external NV run | 519 | 21 | 165 |
| Fresh-process canonical stability | 100 / 100 | 0 | — |

The hardware run took 16 minutes 55 seconds and shut down cleanly. All selected upstream tests and tolerances are unchanged; the existing skip conditions explain the backend-specific count differences. Hardware execution was at b34b6da, followed only by two CPU test-maintenance commits (56679fe and d72c079). `qualification-summary.json` verifies that production code and every selected hardware test are identical at the final candidate. The combined CPU gate passed on the exact final file contents. Ruff and Mypy pass.

The USB suite retains all ten samples per transfer direction. Excluding the first transfer only for the warm summary, the median was **107.65 MB/s upload** and **1.57 MB/s download**, using 2.00 MB transfers. First-use measurements were 749.30 ms upload and 1833.29 ms download. These are local suite measurements, not a comparison with a directly attached 3090. The complete 64 MiB round trip, 300-copy batch, mixed directions, changing-input JIT replays, boundaries, and completion-sentinel patterns all passed.

Starting branch: `codex/chestnut-usb-stability`, HEAD `1ad9c67c41f090b09681138ef010e33c52998261`.
Comparison: upstream main at the rebased commit `fec703cbecad430857c6bedd94a9500e871a4bcc`.
All five selected smoke/backend/JIT test files and `test/helpers.py` are identical to upstream (see `test-source-comparison.json`).

Hardware is exclusively the external Chestnut RTX3090 FE on USB port 4-1, 10000 Mb/s. The runner validates USBIface, USBPCIDevice, bus and PCI/subsystem identities, holds the canonical runner lock, runs pytest serially with stop-on-first-failure, and records normal cleanup errors. CPU references use DEV=CPU. No internal GPU is used.

## Preserved failures

- `smoke-jit-01`: 9 passed, 1 skipped, FP16 GEMM failed because NVRTC could not locate cuda_fp16.h. Installed CUDA 12.8 headers match NVRTC 12.8; configuring CUDA_PATH to the existing nvidia/cuda_runtime package resolves compilation. No source change.
- `smoke-jit-02`: all 20 applicable smoke tests passed, 2 image tests skipped. First JIT test failed with native NV memory handle collision while allocating 32 bytes. Clean shutdown.
- `jit-counters-red`: same original upstream JIT test failed alone in a fresh process. Clean shutdown.
- `memory-reuse-red-03`: CPU regression reproduces the same handle collision with allocate/free/reallocate. Earlier two regression drafts failed due to test fixture setup; they are retained and are not claimed as bug reproductions.

## CPU comparison at starting HEAD

Both upstream and branch: 512 passed, 19 skipped, 126 passing subtests. Full logs and JUnit XML are retained. Upstream ran from a Git archive, with no branch/history changes. `upstream-outcome-comparison.json` independently compares all 531 test names and outcomes: upstream and branch CPU results match exactly, including skip reasons. The NV run uses that same test selection; 508 tests pass on both CPU and NV. All 21 NV skip reasons and the backend-dependent differences are retained in that comparison.

## Hardware command pattern

From tinygrad, using the repository .venv:

```sh
DEV=USB+NV:CUDA PYTHONPATH=. PYTHONUNBUFFERED=1 CUDA_VISIBLE_DEVICES= \
CUDA_PATH="$PWD/.venv/lib/python3.12/site-packages/nvidia/cuda_runtime" TEST_TIMEOUT=300 \
.venv/bin/python ../linux-current-evidence/backend-usb-qualification-20260909/run_hardware_pytest.py UNIQUE_RUN_LABEL TEST_PATHS...
```

Every run label must be new. pytest uses -n0 -x -vv --tb=short -ra and writes a JUnit report; repository conftest enforces TEST_TIMEOUT per test. FORWARD_ONLY and SKIP_SLOW_TEST are unset. Existing upstream skip conditions remain active. Multi-GPU tests skip because only one GPU is in scope.

The selected backend/JIT and USB gates and the final 100-process confirmation have passed. The older 100/100 remains evidence for starting HEAD only; the new result independently qualifies the final candidate for that workload.

## Runtime fixes found by broader tests

1. `4b37c24`: remove native memory registration after freeing VRAM. All 18 interface tests and the original JIT counters test passed after the change. Native/USB CPU tests: 80 passed, 68 subtests; Ruff and Mypy passed.
2. `219f6b8`: The combined run at 4b37c24 passed the earlier JIT tests but timed out in `TestJitPrune.test_prune_w_copy_correct`. It passes alone; the pair `TestCopyInsideJit.test_copy_inside_jit` then `TestJitPrune.test_prune_w_copy_correct` reproduces the stall. Trace 02 found the upload idle loop polling unrelated storage, not the actual device timeline (actual timeline [16,16], unrelated address 0x800fe8000 held 0x561000050000). NV USB still used removed `timeline_signal`/`timeline_value` placeholder tags after upstream merged them into `timeline`.

The first trace draft was interrupted because its diagnostic attempted unbounded iteration of MMIOInterface; no test completed, and ordinary cleanup succeeded. Trace 02 corrected that logging issue and reproduced the original failure. All trace instrumentation is confined to the evidence directory. Explicit external-only resets after aborted runs are logged separately. No reset occurs within a test sequence.

The timeline fix passed the original two-test sequence with no tracing or recovery: 2 passed in 25.27s, clean shutdown. The CPU FFI/interface gate passed 29 tests and 27 subtests. Combined native/HCQ CPU gate at 219f6b8: 97 passed, 17 skipped, 106 subtests. Mypy: 218 source files clean.

## Large einsum failure at 219f6b8

`backend-jit-04` completed all selected JIT tests and then timed out in `TestOps.test_einsum_ellipsis`. The isolated test and its final large subcase reproduced the failure. That subcase uploads two FP32 arrays of shape (32,7,24,24,24), checks an einsum reduction, and compares both gradients with Torch. Each input is 12,386,304 bytes. Upstream and branch CPU references pass this case.

One and two pure copies of the same input size pass, so size alone is insufficient. A diagnostic trace of the minimized einsum shows the copy engine stopping before any arithmetic kernel launches. `large-einsum-fault.json` records timeline [27,28], fault type 13 (REGION_VIOLATION), GPU VA 0x1009600000, and the containing allocation's physical segments. The failing location maps to physical address 0x10000000 (256 MiB). The unsupported debugger-control error following the signal timeout is secondary, not the original fault.

`memory-state.json` records normal initialization on the unchanged failing commit: VPR state 0x38 (initialization required), WPR1 limited to 0x240000..0x27ffff, empty WPR2, 24 GiB VRAM, and a 32 GiB BAR1. The BAR aperture is therefore not the 256 MiB limit. The archived handoff's `vpr-scrubber-boot-02.jsonl` already records a successful run of NVIDIA's signed memory scrubber, clearing the VPR state to 0x28. The native runtime packages that same firmware but omitted the initialization step.

The normal initialization behavior is supported by [Nouveau's GA102 framebuffer implementation](https://raw.githubusercontent.com/torvalds/linux/master/drivers/gpu/drm/nouveau/nvkm/subdev/fb/ga102.c), [its VPR state check](https://raw.githubusercontent.com/torvalds/linux/master/drivers/gpu/drm/nouveau/nvkm/subdev/fb/tu102.c), and [framebuffer initialization](https://raw.githubusercontent.com/torvalds/linux/master/drivers/gpu/drm/nouveau/nvkm/subdev/fb/base.c). Local source inspection used archived Linux revision df2908090cda368b01ff43709f51890076c56157. Firmware bytes, signatures, and protected-range checks remain unchanged.

`vram-init-red.log` demonstrates the missing initialization at the normal bootstrap seam: ACR starts while the simulated VPR state still requires initialization. Fix `ba8e4eb` conditionally executes the packaged signed scrubber before ACR, checks that initialization succeeded, and uses the NVDEC-specific reset and second register-window layout. It preserves both errors if initialization and cleanup fail. Tests cover locked memory, already initialized memory, firmware returning without completing initialization, and actual register encoding for NVDEC's second window.

The original minimized large einsum passes in 48.59 seconds with full forward/gradient comparisons and clean shutdown (`large-einsum-vram-init`). The final CPU gate passes 99 tests, skips 17, and passes 109 subtests. Ruff and Mypy pass. The complete unchanged upstream smoke/backend/JIT selection was then run at the committed fix in `backend-jit-05`.

`backend-jit-05` passed the original einsum in the complete sequence, but stopped at `TestOps.test_std` after 452 passes, 20 skips, and 124 passing subtests (672.50 seconds). The second std subcase, correction=0, returns the original input instead of its gradient for 13,124 of 13,125 elements. This is a correctness failure, not a tolerance adjustment or timeout. Normal cleanup succeeded. The first-failure log, JUnit, and run metadata are preserved. This became the next investigation, resolved by the readback ordering fix below.

## Readback ordering failure

The original std test reproduces alone. The correction=0 subcase passes alone, while corrections 1 then 0 on a flat 13,125-element vector reproduce. Smaller 16- and 1024-element vectors pass. `std-binding-trace-03` preserves the actual failure with runtime input addresses: input/output buffers swap between the cases, and the runtime binds the expected addresses. The first two trace drafts failed on diagnostic UOp/Buffer handling; neither is counted as reproduction evidence. The corrected trace was checked on CPU before hardware use.

`std-scaled-probe` shows correct values when the GPU subsequently multiplies the gradient by two. `std-sync-probe` passes with an explicit synchronize before the failing read, distinguishing premature readback from the arithmetic or address binding. The USB download path creates its own copy-engine submit, bypassing the ordinary batch scheduler and its prior-device timeline wait. Its completion flag proves the copy finished, but did not prove the producing compute work finished before that copy started.

Fix `48387ec` adds the current device timeline wait before each readback staging copy. `readback-order-red.log` demonstrates that both single- and multi-window readbacks previously lacked that ordering. Existing backend tests and numerical tolerances remain unchanged. The complete original std test passes in 24.93 seconds with clean shutdown and no tracing or test-side synchronization (`std-readback-green`). CPU FFI/interface gate: 36 passed, 17 skipped, 40 passing subtests. Ruff and Mypy pass.

## USB suite adaptation

Commit `b34b6da` adapts `test/external/external_test_usb_asm24.py` to the selected USB backend, with native NV transfer windows taken from the runtime and existing AMD constants retained. Non-USB targets skip before hardware selection. Coverage includes packet/slot/window boundaries, complete byte comparisons, 300-copy batches, mixed-direction transfers, fresh inputs on JIT replays, zero/one and existing completion-tag sentinels with exact tail lengths, and a 64 MiB full readback. Two existing timing tests each measure ten transfers. The CPU target skips all nine hardware tests.

`backend-jit-usb-06` completed all 531 unchanged upstream smoke/backend/JIT tests followed by the nine adapted USB tests in one serial process at clean commit b34b6da: **519 passed, 21 skipped, 165 passing subtests**, exit 0, and no cleanup errors. Console capture was disabled only to preserve transfer timing output; timeouts, inputs, numerical tolerances, and skip settings were unchanged.

## CPU test maintenance discovered during qualification

The combined CPU gate exposed an older readback test expecting two commands; it now checks the producer wait, copy, and completion signal in that order. The dedicated single-/multi-window regression remains intact.

The staging fixture also failed only after other CPU tests had run. This reproduced deterministically by executing a small CPU transfer before the fixture (`cpu-staging-warm-red.log`), then by warming the matcher inside the test itself (`staging-fixture-red.log`). `deconstruct_function` in `tinygrad/uop/ops.py` copies function globals into the compiled matcher, so rebinding module-level Device did not reach an already compiled matcher. The fixture now mocks `Device.__getitem__` on the original object and primes the matcher before that mock. Production code is unaffected. The focused gate passes 44 tests and 67 subtests (`staging-fixture-green.log`).

The initial combined CPU failures and the repeat that isolated the staging issue are retained in `final-cpu-b34b6da` and `final-cpu-02`; neither is counted as a pass. The final combined gate passed in `final-cpu-03`: **612 passed, 45 skipped, 237 passing subtests** in 47.62 seconds. During the hardware run, only these unselected CPU fixture tests were edited; production code and every selected hardware test remain identical to b34b6da.

## Final fresh-process acceptance

The unchanged canonical benchmark completed **100 consecutive fresh-process passes** from 17:39:23 to 18:19:27 UTC on 2026-09-09 (40 minutes 4 seconds), at final HEAD `d72c079de9af8d0639933b7b549661a0f798d2b9`, tree `2d3be901b3f439d8b1b9be997dea91b2a35bf982`. There were no failures, retries, recovery steps, or code/benchmark/settings changes during the series. Each process normally initialized the external GPU, uploaded both inputs, computed a 32×32 FP32 matrix multiplication, compared every one of the 1,024 output elements, and shut down cleanly. These are fresh application processes, not physical power cycles.

`audit_fresh100.py` independently checked all 100 numbered attempt records, every stdout/stderr hash, clean exit codes, empty stderr, chronological non-overlapping attempts, hardware identity, matching code and harness hashes, full element count, and the expected output digest. The audit passed. Median wall time per process was 24.015 seconds (range 23.838–24.060 seconds).

- [Canonical manifest and all attempt artifacts](../nv-usb-stability-runs/20260909T173923.911945Z-d72c079de9af-100/manifest.json)
- [Independent audit](fresh100-audit.json)
- [Complete hardware JUnit results](backend-jit-usb-06/junit.xml)
- [Hardware provenance and cleanup](backend-jit-usb-06/result.json)
- [Final CPU JUnit results](final-cpu-03.xml)
- [Upstream outcome comparison and skip reasons](upstream-outcome-comparison.json)
- [Machine-readable qualification summary](qualification-summary.json)

All four runtime issues discovered by the broader suites have separate focused fixes and regression coverage. The additional commits adapt the USB suite and repair two CPU fixtures without changing the selected upstream test sources or tolerances. This acceptance covers the specified GPU, transport, software environment, and selected workloads.
