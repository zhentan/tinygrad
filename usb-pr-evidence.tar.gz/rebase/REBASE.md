# USB branch rebase onto fork master

Final branch head `d3df666b84c1af840eaab042385212dae2626ac6` is rebased onto fork/upstream master `b45cee5ccd127266a70a8fed14ebe43196f7d95d` (11 upstream commits beyond the old base). The fork USB branch was updated with an exact force-with-lease against its previously observed head `d72c079de9af8d0639933b7b549661a0f798d2b9` and the resulting remote SHA was verified. Fork master is unchanged; no upstream branch was pushed and PR #1 remains in the user's fork.

The old tested head is preserved locally by `backup/chestnut-before-fork-rebase-20260909-d72c079`. All 89 original USB commits were replayed, with none dropped or squashed. The branch now contains those 89 commits, two focused integration fixes and one ADR commit. `range-diff-final.txt` records the mapping.

## Integration and preserved failures

Two rebase conflicts combined independent test imports and retained native USB copy staging before upstream's new generic buffer mapping. The removed generic `host_devs` API was not restored.

The first CPU gate exposed an unbound-placeholder fixture incompatible with earlier buffer resolution. The isolated regression failed before the buffer-backed mock adjustment and passed afterward. Commit `235c2c83b` changes only that fixture.

The first rebased full hardware run at `235c2c83b` passed correctness (519 tests, 21 skips, 165 passing subtests) but regressed warm transfer rates to 3.43 MB/s upload and 1.21 MB/s download. `copy-compile-trace-02` showed repeated compilation/cache misses after copy preparation. The first trace attempt failed to acquire the runner lock before any GPU access; it is retained and not counted as a test run.

Commit `8eb65a7d2` reuses buffer-free parameterized staging graphs, keyed by the staging window, while leaving concrete-buffer graphs uncached. The CPU regression failed in both directions before the fix and passed afterward. An isolated hardware check passed both transfer tests and the existing buffer-retention test. All diagnostic logs and candidate patches are retained.

## Final validation

The complete hardware gate ran on clean runtime/test commit `8eb65a7d20a9de40a5ad2ebee42fd8ab2fddc25a`, tree `f4d68b61132b877f06905d6665ebc7c026003bc4`: **520 passed, 21 skipped, 165 passing subtests**, 926.74 seconds of pytest time. All nine USB tests passed, including every byte of a 64 MiB round trip; the existing buffer-retention test passed. Pytest and the outer process exited zero, and normal cleanup reported no errors (`hardware-02`).

The final combined CPU/reference gate passed **636 tests, 44 skips, 239 passing subtests** in 44.39 seconds (`cpu-03`). Mypy passed for 218 files and Ruff passed. The five selected upstream smoke/operator/JIT test files and their helper are byte-identical to `b45cee5ccd127266a70a8fed14ebe43196f7d95d`; their source hashes are recorded in `test-source-comparison.json`. Collected subtests are reported separately from ordinary test counts.

The final head adds only `docs/adr/0001-native-nv-over-chestnut-usb.md` to the fully tested runtime/test commit. A clean fresh-process canonical run on that final head passed with all 1,024 FP32 matrix outputs verified, empty stderr, exit zero and unchanged source/harness hashes. `fresh-process.json` independently audits its manifest, attempt artifacts and external hardware identity. This is **one** post-rebase fresh-process pass, not a new 100-run qualification.

## Transfer measurements

`final-transfer-samples.json` preserves all ten 2.00 MB samples per direction. First transfers in the full sequence were 719.21 ms upload and 1,796.11 ms download. Medians of the remaining nine samples were **98.20 MB/s upload and 1.56 MB/s download**. Prior pre-rebase medians were 107.65 and 1.57 MB/s; the remaining roughly 8.8% upload difference is reported without attributing a cause. These figures describe host/device transfers, not GPU arithmetic throughput or startup latency. The isolated post-fix upload result, 97.75 MB/s, is a separate measurement.

All hardware validation selected only the external Chestnut RTX 3090 FE with `DEV=USB+NV:CUDA`, the unchanged identity guard and canonical runner lock, serial execution and stop-on-first-failure. No hidden retry or recovery was added. Existing skips and tolerances are retained. The evidence qualifies this board/firmware setup, not multi-GPU, all GA102 variants or full VRAM capacity.

The earlier **100/100 belongs only to `d72c079de9af8d0639933b7b549661a0f798d2b9`**. The archive retains every original attempt and its independent audit; the count is not transferred to the rebased code. The evidence branch for PR #1 stores the archive outside the PR's code diff.
