# NV: support RTX 3090 compute over Chestnut USB

Add `DEV=USB+NV:CUDA` for an external RTX 3090 FE connected through Chestnut: initialize normally, upload inputs, execute tensor and TinyJit programs, verify readback, and shut down cleanly.

The implementation reuses NV's renderer, compiler, queue encoding and HCQ execution model. Native GA102 setup supplies signed firmware, engine contexts and channels; USB staging expresses transport constraints in the existing dependency graph.

## Implementation and scope

- Discover the tunneled PCIe endpoint and configure BARs, initialization and cleanup.
- Initialize GA102 using NVIDIA's signed firmware, including required VRAM initialization.
- Stage uploads through reserved 256 KiB controller SRAM and downloads through a separate VRAM window, with explicit producer/copy ordering.
- Preserve runtime address dependencies, timeline values, byte lanes and allocation reuse; check transfer status and length before dependent work.
- Adapt the existing USB integrity suite to the NV backend and its actual staging windows.

The runtime/test diff against upstream `b45cee5` is **4,043 additions and 113 removals across 22 files**, excluding the ADR. Of the additions, 1,996 are tests and 2,047 are runtime code; 1,489 runtime additions implement missing GA102 initialization/context setup in three modules. Shared HCQ changes are +50/−10 lines and the executor adds four lines. The design favors existing abstractions and concise functions, with explicit hardware-state checks.

See the [architecture decision](https://github.com/zhentan/tinygrad/blob/codex/chestnut-usb-stability/docs/adr/0001-native-nv-over-chestnut-usb.md) for initialization, transfer ordering, ownership and every changed code/test file.

## Stability findings and rebase integration

Rebased all 89 original commits onto `b45cee5`, preserving their order and keeping an old-head backup. Two focused integration commits address upstream's earlier buffer resolution and its changed HCQ cache lookup.

- **Readback ordering — `55004315a`:** direct USB download submission bypassed ordinary batch scheduling. Its completion flag showed that the copy finished, but did not order it after the producing kernel. Waiting on the current device timeline before each staging copy fixed stale gradient readback in the unchanged upstream `test_std` case. Single- and multi-window ordering regressions cover it.
- **Repeated compilation after rebase — `8eb65a7d2`:** upstream now looks up the HCQ cache after copy preparation. Fresh scratch parameters made otherwise equivalent USB transfers miss that cache. Reusing parameterized staging graphs, keyed by the staging window, removes per-copy recompilation. Concrete application buffers bypass this cache; the existing buffer-retention test passes.

The first rebased correctness run passed but warm rates dropped to **3.43 MB/s upload and 1.21 MB/s download**. Traces and the failing/passing compiler regression are retained. Final post-fix measurements are below. Earlier focused fixes for allocation-registration reuse, upload timeline storage and signed VRAM initialization remain in the branch.

## Validation

At the rebased runtime/test commit `8eb65a7d20a9de40a5ad2ebee42fd8ab2fddc25a`, the complete selected hardware gate passed **520 tests, with 21 skips and 165 passing subtests**. This includes all nine USB integrity/timing tests and the existing HCQ buffer-retention test. Pytest, process exit and normal device cleanup succeeded. The CPU/reference gate passed **636 tests, with 44 skips and 239 passing subtests**; mypy passed for 218 source files and Ruff passed. The selected five upstream smoke/operator/JIT files and their test helper are byte-identical to `b45cee5`.

The hardware setup was one external RTX 3090 FE through Chestnut, a negotiated 10,000 Mb/s USB link, and CUDA/NVRTC with matching headers. Hardware runs are serial, stop at the first failure, and retain skips and numerical tolerances. USB checks cover packet/slot/window boundaries, 300-copy batches, mixed directions, changing-input TinyJit replay, completion-sentinel payloads, and every byte of a **64 MiB round trip**. Operator tests include forward results and gradients.

Final PR head `d3df666b84c1af840eaab042385212dae2626ac6` adds only the ADR to that tested runtime/test commit. It also passed **one fresh-process canonical benchmark run**, independently audited for clean exit, empty stderr, all 1,024 output values, unchanged source/harness hashes and the external GPU identity.

The pre-rebase head `d72c079` separately passed **100 consecutive fresh-process runs**: normal initialization, two uploads, 32×32 FP32 matmul, all 1,024 outputs checked, and clean shutdown. All attempt records and hashes were independently audited, with unchanged code/benchmark/settings and no retries or recovery in the series. **That 100/100 result belongs to the pre-rebase head and is not a 100/100 claim for this PR revision.**

## Transfer measurements

Each sequence retained ten 2.00 MB transfers per direction. Warm throughput is the median of samples 2–10; first samples are shown separately. These are first transfers within the already-running full test process, not GPU startup latency.

| Revision | Upload first | Upload warm median | Download first | Download warm median |
| --- | ---: | ---: | ---: | ---: |
| Pre-rebase `d72c079` | 749.30 ms | 107.65 MB/s | 1,833.29 ms | 1.57 MB/s |
| Rebased/fixed `8eb65a7d2` | 719.21 ms | **98.20 MB/s** | 1,796.11 ms | **1.56 MB/s** |

Upload remains about 8.8% below the earlier sample median; these runs do not isolate that difference's cause. Download bandwidth remains limited. Transfer rates are not arithmetic throughput or application speedups; the small repeated matmul is a stability check. Qualification covers this board/firmware and single-device setup, not every GA102 variant, multi-GPU behavior or full 24 GiB capacity.

## Performance context and current limitation

These transfer rates are low relative to a 10 Gb/s link's nominal **1,250 MB/s before overhead**: about **7.9% upload and 0.125% download**. The measured 2 MB copy takes about **20 ms to upload and 1.28 seconds to download**. This is initial hardware support with measured limitations, not evidence of high transfer performance. [USB-IF signaling-rate definitions](https://www.usb.org/sites/default/files/usb_data_performance_language_usage_guidelines_jan_2024.pdf)

The directions use different mechanisms. Upload uses controller SRAM/DMA. Download uses F0 PCIe streaming: the pinned firmware fills USB packets through an 8051 programmed-I/O loop that reads **four bytes per iteration**, preparing at most 1 KiB per USB packet. This strongly explains the asymmetry; stage-by-stage timings are still needed to quantify the bottleneck. [Firmware read loop](https://github.com/tinygrad/asm2464pd-firmware/blob/ed4e39b7e0794e19ba193477067c48757a5cf9ef/handmade/src/pcie_pio.h#L27), [packet handling](https://github.com/tinygrad/asm2464pd-firmware/blob/ed4e39b7e0794e19ba193477067c48757a5cf9ef/handmade/src/main.c#L135)

Workloads that keep weights/intermediates on the GPU and return small results could amortize these costs. Frequent large readbacks or CPU/GPU offload are poor fits. An end-to-end workload against a CPU baseline is still needed before claiming application speedup; correctness tests and a small repeated matmul do not establish that benefit.

## Evidence

The [evidence branch](https://github.com/zhentan/tinygrad/tree/evidence/chestnut-usb-b45cee5-20260909) contains the downloadable archive, SHA-256 checksum, raw logs/JUnit results, all 100 historical attempt records, final rebase validation, retained failure/fix evidence, and unchanged benchmark/runner source. Generated evidence is kept outside this PR's code diff.
