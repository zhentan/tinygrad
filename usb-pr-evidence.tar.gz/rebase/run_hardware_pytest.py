"""Serial, identity-checked qualification using the repository's unchanged pytest tests."""
import fcntl, gc, hashlib, json, os, random, subprocess, sys, time, traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from nv_usb_stability_benchmark import chestnut_inventory, runtime_identity, cleanup_device

assert os.environ.get("DEV") == "USB+NV:CUDA"
label, *tests = sys.argv[1:]
out = HERE / label
out.mkdir(exist_ok=False)
lock = (HERE.parent / "nv-usb-stability-runs/.runner.lock").open("a")
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
git = lambda *args: subprocess.check_output(["git", *args], text=True).strip()
diff = subprocess.check_output(["git", "diff", "HEAD"])
(out / "candidate.diff").write_bytes(diff)
result = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
          "diff_sha256": hashlib.sha256(diff).hexdigest(), "status": git("status", "--porcelain"),
          "tests": tests, "target": os.environ["DEV"], "started": time.time(), "python": sys.executable,
          "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "environment": {k: os.environ.get(k) for k in ("CUDA_PATH", "CUDA_VISIBLE_DEVICES", "TEST_TIMEOUT", "FORWARD_ONLY", "SKIP_SLOW_TEST")}}
def save(): (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
save()
dev = None
exit_code = 1
try:
  inventory = chestnut_inventory()
  from tinygrad import Device, Tensor
  from tinygrad.helpers import DEV
  original_getitem = type(Device).__getitem__
  def guarded_getitem(self, name):
    name = self.canonicalize(name)
    if name.split(":")[0] == "NV":
      if name != "NV": raise RuntimeError("qualification has only one external GPU")
      assert DEV.target("NV").interface == "USB", "qualification requires NV over USB"
    elif name.split(":")[0] not in ("CPU", "NPY", "DISK", "PYTHON", "NULL"):
      raise RuntimeError(f"device outside qualification scope: {name}")
    return original_getitem(self, name)
  type(Device).__getitem__ = guarded_getitem
  dev = Device["NV"]
  result["identity"] = runtime_identity(dev, inventory)
  save()
  print(json.dumps(result), flush=True)
  random.seed(0)
  import numpy as np
  np.random.seed(0)
  Tensor.manual_seed(0)
  import pytest
  exit_code = int(pytest.main(["-n0", "-x", "-vv", "--tb=short", "-ra", f"--junitxml={out / 'junit.xml'}", *tests]))
except BaseException:
  result["exception"] = traceback.format_exc()
  traceback.print_exc()
finally:
  gc.collect()
  result["cleanup_errors"] = [] if dev is None else cleanup_device(dev, Device)
  result["pytest_exit_code"] = exit_code
  result["finished"] = time.time()
  result["exit_code"] = exit_code or bool(result["cleanup_errors"])
  save()
  print(json.dumps(result), flush=True)
sys.exit(result["exit_code"])
