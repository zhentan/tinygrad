"""Diagnostic pytest plugin: measure HCQ compilation without changing the candidate."""
import json
import sys
import time


def pytest_configure(config):
  from tinygrad.engine import realize
  from tinygrad.runtime.support import hcq2
  original = realize.hcq_compile

  def traced(linear, input_uops, profile, cache=False):
    before = len(hcq2.hcq_compile_cache)
    started = time.perf_counter()
    result = original(linear, input_uops, profile, cache=cache)
    elapsed = (time.perf_counter() - started) * 1000
    print('[COPY-COMPILE] ' + json.dumps({
      'ms': round(elapsed, 3), 'cache': cache, 'entries_before': before,
      'entries_after': len(hcq2.hcq_compile_cache), 'calls': len(linear.src),
      'inputs': None if input_uops is None else len(input_uops),
    }), file=sys.stderr, flush=True)
    return result

  realize.hcq_compile = traced
